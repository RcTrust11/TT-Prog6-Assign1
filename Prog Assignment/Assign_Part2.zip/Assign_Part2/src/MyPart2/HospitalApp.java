package MyPart2;

import java.time.LocalDate;
import java.util.Scanner;

public class HospitalApp {
    private static final Scanner in = new Scanner(System.in);
    private static Doctor doctor;

    public static void main(String[] args) {
        System.out.print("Enter doctor name: ");
        doctor = new Doctor(in.nextLine(), 5);

        boolean running = true;
        while (running) {
            switch (menu()) {
                case 1: addPatient();
                          break;
                case 2 : 
                    addEmergencyPatient();
                        break;
                case 3 :
                    findPatient();
                    break;
                case 4 : 
                    System.out.println(doctor.report());
                    break;
                case 0 : 
                    running = false;
                    break;
                default :
                    System.out.println("Invalid option");
            }
        }
    }

    private static int menu() {
        System.out.println("**********************************************");
        System.out.println("************* Hospital Manager ***************");
        System.out.println("**********************************************");
        System.out.println("\n 1). Add Patient"
                + "\n 2). Add Emergency Patient"
                + "\n 3). Find Patient by ID"
                + "\n 4). Doctor's Report"
                + "\n 0). Exit");
        System.out.print("Choice: ");
        return Integer.parseInt(in.nextLine());
    }

    private static void addPatient() {
        System.out.print("ID: "); String id = in.nextLine();
        System.out.print("Name: "); String name = in.nextLine();
        System.out.print("Age: "); int age = Integer.parseInt(in.nextLine());
        System.out.print("Condition: "); String condition = in.nextLine();
        doctor.addPatient(new Patient(id, name, age, condition));
    }

    private static void addEmergencyPatient() {
        System.out.print("ID: "); String id = in.nextLine();
        System.out.print("Name: "); String name = in.nextLine();
        System.out.print("Age: "); int age = Integer.parseInt(in.nextLine());
        System.out.print("Condition: "); String condition = in.nextLine();
        System.out.print("Admission date (YYYY-MM-DD): ");
        LocalDate admission = LocalDate.parse(in.nextLine());
        System.out.print("Severity (1-5): "); int severity = Integer.parseInt(in.nextLine());
        doctor.addPatient(new EmergencyPatient(id, name, age, condition, admission, severity));
    }

    private static void findPatient() {
        System.out.print("Enter patient ID: ");
        String id = in.nextLine();
        Patient p = doctor.findById(id);
        if (p == null) {
            System.out.println("Patient not found.");
        } else {
            System.out.println(p);
        }
    }
}
