package MyPart2;

import java.time.LocalDate;

public class EmergencyPatient extends Patient {
    private LocalDate admissionDate;
    private int severityLevel; // 1 = mild, 5 = critical

    public EmergencyPatient(String id, String name, int age, String condition, LocalDate admissionDate, int severityLevel) {
        super(id, name, age, condition);
        setAdmissionDate(admissionDate);
        setSeverityLevel(severityLevel);
    }

    public LocalDate getAdmissionDate() { return admissionDate; }
    public void setAdmissionDate(LocalDate admissionDate) {
        if (admissionDate == null) throw new IllegalArgumentException("Admission date required");
        this.admissionDate = admissionDate;
    }

    public int getSeverityLevel() { return severityLevel; }
    public void setSeverityLevel(int severityLevel) {
        if (severityLevel < 1 || severityLevel > 5)
            throw new IllegalArgumentException("Severity must be between 1 and 5");
        this.severityLevel = severityLevel;
    }

    @Override
    public String toString() {
        return super.toString() + " | Admitted: " + admissionDate + " | Severity: " + severityLevel;
    }
}
