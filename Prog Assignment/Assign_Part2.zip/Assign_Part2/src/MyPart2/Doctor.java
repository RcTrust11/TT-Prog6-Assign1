package MyPart2;

import java.util.Arrays;

public class Doctor {
    private String name;
    private Patient[] patients;
    private int size;

    public Doctor(String name, int capacity) {
        if (name == null || name.isBlank()) throw new IllegalArgumentException("Doctor name required");
        this.name = name.trim();
        patients = new Patient[capacity < 1 ? 1 : capacity];
        size = 0;
    }

    public String getName() { return name; }

    public void addPatient(Patient patient) {
        if (patient == null) throw new IllegalArgumentException("Patient required");
        ensureCapacity(size + 1);
        patients[size++] = patient;
    }

    public Patient findById(String id) {
        for (int i = 0; i < size; i++) {
            if (patients[i].getId().equals(id)) return patients[i];
        }
        return null;
    }

    public String report() {
        StringBuilder sb = new StringBuilder("\n--- Patients under Dr. " + name + " ---\n");
        for (int i = 0; i < size; i++) {
            sb.append(patients[i]).append("\n");
        }
        sb.append("Total Patients: ").append(size).append("\n");
        return sb.toString();
    }

    private void ensureCapacity(int min) {
        if (min <= patients.length) return;
        patients = Arrays.copyOf(patients, patients.length * 2);
    }
}
