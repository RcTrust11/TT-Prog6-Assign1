package MyPart2;

public class Patient {
    private final String id;
    private String name;
    private int age;
    private String condition;

    public Patient(String id, String name, int age, String condition) {
        if (id == null || id.isBlank()) throw new IllegalArgumentException("ID required");
        if (name == null || name.isBlank()) throw new IllegalArgumentException("Name required");
        if (age < 0) throw new IllegalArgumentException("Age must be >= 0");
        if (condition == null || condition.isBlank()) throw new IllegalArgumentException("Condition required");

        this.id = id.trim();
        this.name = name.trim();
        this.age = age;
        this.condition = condition.trim();
    }

    public String getId() { return id; }
    public String getName() { return name; }
    public int getAge() { return age; }
    public String getCondition() { return condition; }

    public void setName(String name) {
        if (name == null || name.isBlank()) throw new IllegalArgumentException("Name required");
        this.name = name.trim();
    }

    public void setAge(int age) {
        if (age < 0) throw new IllegalArgumentException("Age must be >= 0");
        this.age = age;
    }

    public void setCondition(String condition) {
        if (condition == null || condition.isBlank()) throw new IllegalArgumentException("Condition required");
        this.condition = condition.trim();
    }

    @Override
    public String toString() {
        return id + " | " + name + " | Age: " + age + " | Condition: " + condition;
    }
}
