/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package Holder;

import org.junit.Test;
import static org.junit.Assert.*;
import java.util.Arrays;

public class SeriesTest {
    
    public SeriesTest() {
    }

    @Test
    public void testMenuScreen() {
        
        assertTrue(true);
    }

    @Test
    public void testCaptureSeries() {
      
        Series.seriesDetails.clear();
        Series.seriesDetails.addAll(Arrays.asList("S1","Naruto","15","220"));
        
        assertEquals(4, Series.seriesDetails.size());
        assertEquals("S1", Series.seriesDetails.get(0));
        assertEquals("Naruto", Series.seriesDetails.get(1));
    }

    @Test
    public void testSearchSeries() {
        Series.seriesDetails.clear();
        Series.seriesDetails.addAll(Arrays.asList("S1","Naruto","15","220"));
        
        boolean found = false;
        for (int i = 0; i < Series.seriesDetails.size(); i += 4) {
            if (Series.seriesDetails.get(i + 1).equalsIgnoreCase("Naruto")) {
                found = true;
                break;
            }
        }
        assertTrue(found);
    }

    @Test
    public void testUpdateSeries() {
        Series.seriesDetails.clear();
        Series.seriesDetails.addAll(Arrays.asList("S1","Naruto","15","220"));
        
        
        for (int i = 0; i < Series.seriesDetails.size(); i += 4) {
            if (Series.seriesDetails.get(i).equals("S1")) {
                Series.seriesDetails.set(i + 2, "16");
            }
        }
        assertEquals("16", Series.seriesDetails.get(2));
    }

    @Test
    public void testDeleteSeries() {
        Series.seriesDetails.clear();
        Series.seriesDetails.addAll(Arrays.asList("S1","Naruto","15","220"));
        

        for (int i = 0; i < Series.seriesDetails.size(); i += 4) {
            if (Series.seriesDetails.get(i).equals("S1")) {
                for (int j = 0; j < 4; j++) {
                    Series.seriesDetails.remove(i);
                }
            }
        }
        assertTrue(Series.seriesDetails.isEmpty());
    }

    @Test
    public void testSeriesReport() {
        Series.seriesDetails.clear();
        Series.seriesDetails.addAll(Arrays.asList("S1","Naruto","15","220"));
        
        boolean reportIncludesName = false;
        for (int i = 0; i < Series.seriesDetails.size(); i += 4) {
            if (Series.seriesDetails.get(i + 1).equals("Naruto")) {
                reportIncludesName = true;
            }
        }
        assertTrue(reportIncludesName);
    }

    @Test
    public void testExitSeriesApplication() {
        assertTrue(true);
    }
    
}
