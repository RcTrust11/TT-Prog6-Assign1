package Holder;

import java.util.ArrayList;
import java.util.Scanner;

public class Series extends SeriesModel {
    public static String opTaker;
    public static int opCounter;

    public static ArrayList<String> seriesDetails = new ArrayList<>();
    public static Scanner input = new Scanner(System.in);


    public static void MenuScreen() {
      
            System.out.println("Please select one of the following menu items:\n"
                    + "(1) Capture a new Series.\n"
                    + "(2) Search for a series.\n"
                    + "(3) Update Series age restriction.\n"
                    + "(4) Delete a series.\n"
                    + "(5) Print series report - 2025\n"
                    + "(6) Exit Application.");

            opCounter = input.nextInt();
            input.nextLine(); // consume leftover newline

            switch (opCounter) {
                case 1:
                    CaptureSeries();
                    break;

                case 2:
                    SearchSeries();
                    break;

                case 3:
                    UpdateSeries();
                    break;

                case 4:
                    DeleteSeries();
                    break;

                case 5:
                    SeriesReport();
                    break;

                case 6:
                    ExitSeriesApplication();
                    break;

                default:
                    System.out.println("Invalid input entered, please enter a valid input");
                    MenuScreen();
                    break;
            }

       
    }

    public static void CaptureSeries() {
    Scanner input = new Scanner(System.in);

    System.out.println("CAPTURE A NEW SERIES");
    System.out.println("***************************************");

  
    while (true) {
        System.out.print("Enter the series id: ");
        SeriesId = input.nextLine();

        boolean exists = false;
        for (int i = 0; i < seriesDetails.size(); i += 4) {
            if (seriesDetails.get(i).equalsIgnoreCase(SeriesId)) {
                exists = true;
                System.out.println("⚠ Series ID already exists! Please enter a different ID.");
                break;
            }
        }

        if (!exists) {
            seriesDetails.add(SeriesId);
            break; 
        }
    }

    System.out.print("Enter the series name: ");
    SeriesName = input.nextLine();
    seriesDetails.add(SeriesName);

    int Age = -1;
    while (true) {
        System.out.print("Enter the series age restriction (between 2 & 18): ");
        SeriesAge = input.nextLine();

        try {
            Age = Integer.parseInt(SeriesAge);

            if (Age < 2 || Age > 18) {
                System.out.println("You have entered an incorrect series age !!!");
            } else {
                break;
            }
        } catch (NumberFormatException e) {
            System.out.println("Please enter a valid number for age restriction.");
        }
    }
    seriesDetails.add(SeriesAge);

    System.out.print("Enter the number of episodes for the series: ");
    SeriesNumberOfEpisodes = input.nextLine();
    seriesDetails.add(SeriesNumberOfEpisodes);

    System.out.println("Series processed successfully!!!!");

    System.out.println("Enter (1) to launch menu or any other key to exit ");
    opTaker = input.nextLine();
    if (opTaker.equals("1")) {
        MenuScreen();
    } else {
        System.exit(0);
    }
}

    public static void SearchSeries() {
        Scanner input = new Scanner(System.in);
        System.out.println("SEARCH SERIES");
        System.out.println("*********************************************");

        System.out.print("Enter the  series ID to search: ");
        String searchName = input.nextLine();

        boolean found = false;

        for (int i = 0; i < seriesDetails.size(); i += 4) {
            String name = seriesDetails.get(i);
            if (name.equalsIgnoreCase(searchName)) {
                System.out.println("Series Found!");
                System.out.println("Series ID: " + seriesDetails.get(i));
                System.out.println("Series Name: " + seriesDetails.get(i + 1));
                System.out.println("Series Age Restriction: " + seriesDetails.get(i + 2));
                System.out.println("Series Episodes: " + seriesDetails.get(i + 3));
                found = true;
                break;
            }
        }

        if (!found) {
            System.out.println("Series not found.");
        }

        System.out.println("Enter (1) to return to menu or any other key to exit");
        opTaker = input.nextLine();
        if (opTaker.equals("1")) {
            MenuScreen();
        } else {
            System.exit(0);
        }
    }

    public static void UpdateSeries() {
        Scanner input = new Scanner(System.in);
        System.out.println("UPDATE SERIES AGE RESTRICTION");
        System.out.println("*********************************************");

        System.out.print("Enter the ID of the series to update: ");
        String id = input.nextLine();

        boolean found = false;

        for (int i = 0; i < seriesDetails.size(); i += 4) {
            if (seriesDetails.get(i).equals(id)) {
                System.out.print("Enter the new age restriction: ");
                String newAge = input.nextLine();
                seriesDetails.set(i + 2, newAge);
                System.out.println("Age restriction updated successfully.");
                found = true;
                break;
            }
        }

        if (!found) {
            System.out.println("Series ID not found.");
        }

        System.out.println("Enter (1) to return to menu or any other key to exit");
        opTaker = input.nextLine();
        if (opTaker.equals("1")) {
            MenuScreen();
        } else {
            System.exit(0);
        }
    }

    public static void DeleteSeries() {
        Scanner input = new Scanner(System.in);
        System.out.println("DELETE A SERIES");
        System.out.println("*********************************************");

        System.out.print("Enter the ID of the series to delete: ");
        String id = input.nextLine();

        boolean found = false;

        for (int i = 0; i < seriesDetails.size(); i += 4) {
            if (seriesDetails.get(i).equals(id)) {
                for (int j = 0; j < 4; j++) {
                    seriesDetails.remove(i);
                }
                System.out.println("Series deleted successfully.");
                found = true;
                break;
            }
        }

        if (!found) {
            System.out.println("Series ID not found.");
        }

        System.out.println("Enter (1) to return to menu or any other key to exit");
        opTaker = input.nextLine();
        if (opTaker.equals("1")) {
            MenuScreen();
        } else {
            System.exit(0);
        }
    }

    public static void SeriesReport() {
        System.out.println("SERIES REPORT - 2025");
        System.out.println("*********************************************");

        if (seriesDetails.isEmpty()) {
            System.out.println("No series captured yet.");
        } else {
            int seriesCount = 1;
            for (int i = 0; i < seriesDetails.size(); i += 4) {
                System.out.println("*********************************************");
                System.out.println("Series " + seriesCount);
                System.out.println("*********************************************");
                System.out.println("SERIES ID: " + seriesDetails.get(i));
                System.out.println("SERIES NAME: " + seriesDetails.get(i + 1));
                System.out.println("SERIES AGE RESTRICTION: " + seriesDetails.get(i + 2));
                System.out.println("NUMBER OF EPISODES: " + seriesDetails.get(i + 3));
                System.out.println("*********************************************");
                seriesCount++;
            }
        }

        Scanner input = new Scanner(System.in);
        System.out.println("Enter (1) to launch menu or any other key to exit");
        opTaker = input.nextLine();
        if (opTaker.equals("1")) {
            MenuScreen();
        } else {
            System.exit(0);
        }
    }


    public static void ExitSeriesApplication() {
        System.out.println("Thank you for using the Series Management System.");
        System.exit(0);
    }
}
