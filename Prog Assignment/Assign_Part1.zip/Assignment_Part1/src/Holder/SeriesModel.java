package Holder;

public class SeriesModel  {

    public static String getSeriesId() {
        return SeriesId;
    }

    public static void setSeriesId(String SeriesId) {
        SeriesModel.SeriesId = SeriesId;
    }

    public static String getSeriesName() {
        return SeriesName;
    }

    public static void setSeriesName(String SeriesName) {
        SeriesModel.SeriesName = SeriesName;
    }

    public static String getSeriesAge() {
        return SeriesAge;
    }

    public static void setSeriesAge(String SeriesAge) {
        SeriesModel.SeriesAge = SeriesAge;
    }

    public static String getSeriesNumberOfEpisodes() {
        return SeriesNumberOfEpisodes;
    }

    public static void setSeriesNumberOfEpisodes(String SeriesNumberOfEpisodes) {
        SeriesModel.SeriesNumberOfEpisodes = SeriesNumberOfEpisodes;
    }
    public static String SeriesId;
    public static String SeriesName ;
    public static  String SeriesAge ;
    public static String SeriesNumberOfEpisodes;

}
