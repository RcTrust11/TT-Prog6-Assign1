
package Holder;

import static Holder.Series.MenuScreen;
import java.util.Scanner;



public class Main {
    
        public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        
        System.out.println("LATEST SERIES - 2025");
        System.out.println("***************************************");
        System.out.println("Enter (1) to launch menu or any other key to exit ");
        
        int firstOption = input.nextInt();
        if(firstOption == 1){
            MenuScreen();
        }else{
            System.exit(0);
        
        } 
    }
}
